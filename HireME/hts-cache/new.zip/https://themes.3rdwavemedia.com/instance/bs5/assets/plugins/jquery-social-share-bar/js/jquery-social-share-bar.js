<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /instance/bs5/assets/plugins/jquery-social-share-bar/js/jquery-social-share-bar.js was not found on this server.</p>
<hr>
<address>Apache Server at themes.3rdwavemedia.com Port 80</address>
</body></html>
